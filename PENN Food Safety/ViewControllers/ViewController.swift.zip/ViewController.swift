//
//  ViewController.swift
//  PENN Food Safety
//
//  Created by Varun Shukla on 08/07/22.
//

import UIKit
import AppAuth
import WebKit

class ViewController: UIViewController {
    
    /**
     Class property to store the authorization state.
     */
    private var authState: OIDAuthState?
    
    /**
     Reference to a request object built by AppAuth.
     
     This will be used to build AppAuth `OIDAuthorizationResponse` to continue authorization with the SDK after redirection event in the web view.
     */
    var oidAuthorizationRequest: OIDAuthorizationRequest? = nil
    
    /**
     Reference to the class providing web view.
     */
    var webViewController: WebViewController!
    var indicatorView: UIActivityIndicatorView!
    
    /**
     Reference to the web view via its `tag` property.
     */
    var webViewTag = 1
    
    /**
     Completes successful authorization.
     
     This property serve as a placeholder for authorization completion handler for being called from a different context than one the authorization was initiated in. In this example, it sets the authorization state and performs callbacks—if any.
     */
    var authorizationCompletion: ((OIDAuthState?, Error?) -> Void)? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // Displaying the app name as it appears on the user's device, giving preference to the `Display Name` general setting.
        
        navigationItem.title = (Bundle.main.object(forInfoDictionaryKey: "CFBundleDisplayName") ?? Bundle.main.object(forInfoDictionaryKey: "CFBundleName")) as? String
        
        loadState()
        showState()
        
    }
    
    
    
    @IBAction func startBtnClicked(_ sender: Any) {
        if authState == nil {
            indicatorView = self.activityIndicator(style: .medium,
                                                   center: self.view.center)
            self.view.addSubview(indicatorView)
            indicatorView.startAnimating()
            authorizeRp(issuerUrl: FSConstants.AppAuthConfiguration.issuerUrl, configuration: nil)
        }
    }
    
    private func activityIndicator(style: UIActivityIndicatorView.Style = .medium,
                                   frame: CGRect? = nil,
                                   center: CGPoint? = nil) -> UIActivityIndicatorView {
        
        let activityIndicatorView = UIActivityIndicatorView(style: style)
        if let frame = frame {
            activityIndicatorView.frame = frame
        }
        if let center = center {
            activityIndicatorView.center = center
        }
        return activityIndicatorView
        
    }
}

// MARK: OIDC Provider configuration
extension ViewController {
    /**
     Returns OIDC Provider configuration.
     
     In this method the OP's endpoints are retrieved from the issuer's well-known OIDC configuration document location (asynchronously). The response is handled then with the passed in escaping callback.
     */
    func discoverOIDServiceConfiguration(_ issuerUrl: String, completion: @escaping (OIDServiceConfiguration?, Error?) -> Void) {
        // Checking if the issuer's URL can be constructed.
        guard let issuer = URL(string: issuerUrl) else {
            print("Error creating issuer URL for: \(issuerUrl)")
            
            return
        }
        
        print("Retrieving configuration for: \(issuer.absoluteURL)")
        
        // Discovering endpoints with AppAuth's convenience method.
        OIDAuthorizationService.discoverConfiguration(forIssuer: issuer) {
            configuration, error in
            if let error = error  {
                print("Error retrieving discovery document: \(error.localizedDescription)")
                return
            }
            
            guard let configuration = configuration else {
                print("Error retrieving discovery document. Error & Configuration both are NIL!")
                return
            }
            
            // Completing with the caller's callback.
            completion(configuration, error)
            print("Got configuration: \(configuration)")
            
        }
    }
}

// MARK: Authorization methods
extension ViewController {
    /**
     Makes token exchange request.
     
     The code obtained from the authorization request is exchanged at the token endpoint.
     */
    func makeTokenRequest(completion: @escaping (OIDAuthState?, Error?) -> Void) {
        guard let tokenExchangeRequest = self.authState?.lastAuthorizationResponse.tokenExchangeRequest() else {
            print("Error creating access token request.")
            return
        }
        
        print("Making token request with: ", tokenExchangeRequest)
        
        OIDAuthorizationService.perform(tokenExchangeRequest) {
            response, error in
            
            if let response = response {
                print("Received token response with access token: ", response.accessToken ?? "")
            } else {
                print("Error making token request: \(error?.localizedDescription ?? "")")
            }
            
            self.authState?.update(with: response, error: error)
            self.indicatorView.stopAnimating()
            completion(self.authState, error)
        }
    }
    
    /**
     Performs the authorization code flow using a web view.
     
     Attempts to make a request to the authorization endpoint by utilizing a web view.
     Allows the web view to handle the redirection.
     */
    func authorizeWithWebView(
        configuration: OIDServiceConfiguration,
        clientId: String,
        redirectionUri: String,
        scopes: [String] = [OIDScopeOpenID, OIDScopeProfile, "openid"],
        completion: @escaping (OIDAuthState?, Error?) -> Void
    ) {
        // Checking if the redirection URL can be constructed.
        guard let redirectURI = URL(string: redirectionUri) else {
            print("Error creating redirection URL for : \(redirectionUri)")
            
            return
        }
        
        // Building authorization request.
        let request = OIDAuthorizationRequest(
            configuration: configuration,
            clientId: clientId,
            clientSecret: nil,
            scopes: scopes,
            redirectURL: redirectURI,
            responseType: OIDResponseTypeCode,
            additionalParameters: nil
        )
        
        // Making authorization request.
        print("Initiating authorization request with scopes: \(request.scope ?? "no scope requested")")
        
        // Using web view instead of built in AppAuth methods invoking an external user-agent.
        /**
         Reference to the completion handler to be called on successful authorization.
         
         The redirection URI will be processed in the web view navigation event. The code will be exchanged for tokens using the `makeTokenRequest()` method, which will need to follow by the completion callback passed in here from the `authorizeRp()` method. Since the navigation event will be handled in a different context, we need to preserve the completion block.
         */
        authorizationCompletion = completion
        
        /**
         The request object reference accessible from other methods.
         
         AppAuth methods will be used to complete the authorization flow after redirection from the authorization endpoint and need the original request details.
         */
        oidAuthorizationRequest = request
        
        // Dismissing any existing subview.
        view.viewWithTag(webViewTag)?.removeFromSuperview()
        
        // Dismissing any existing web view controller.
        webViewController = nil
        
        // Configuring the web view for JavaScript interactions.
        
        let userContentController = WKUserContentController()
        userContentController.add(self, name: "callback")
        
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = userContentController
        
        // Providing the web view class with initial parameters.
        webViewController = WebViewController.init(
            appGroup: FSConstants.AppAuthConfiguration.appGroup,
            appGroupCookies: FSConstants.AppAuthConfiguration.appGroupCookies,
            webViewFrame: view.bounds,
            webViewConfiguration: configuration
        )
        
        // Setting this controller as the web view navigation delegate.
        webViewController.wkNavigationDelegate = self
        
        // Loading the view with the authorization URL.
        webViewController.loadWebView() {
            webView in
            
            // Tracking the view by its tag.
            webView.tag = self.webViewTag
            
            self.view.addSubview(webView)
            
            // Loading the authorization endpoint URL obtained from the AppAuth authorization request object.
            webView.load(URLRequest(url: URL(string: request.authorizationRequestURL().absoluteString)!))
        }
    }
    
    /**
     Authorizes the Relying Party with an OIDC Provider.
     
     - Parameter issuerUrl: The OP's `issuer` URL to use for OpenID configuration discovery
     - Parameter configuration: Ready to go OIDServiceConfiguration object populated with the OP's endpoints
     - Parameter completion: (Optional) Completion handler to execute after successful authorization.
     */
    func authorizeRp(issuerUrl: String?, configuration: OIDServiceConfiguration?, completion: (() -> Void)? = nil) {
        /**
         Performs authorization with an OIDC Provider configuration.
         A nested function to complete the authorization process after the OP's configuration has became available.
         - Parameter configuration: Ready to go OIDServiceConfiguration object populated with the OP's endpoints
         */
        func authorize(configuration: OIDServiceConfiguration) {
            print("Authorizing with configuration: \(configuration)")
            
            self.authorizeWithWebView(
                configuration: configuration,
                clientId: FSConstants.AppAuthConfiguration.clientId,
                redirectionUri: FSConstants.AppAuthConfiguration.redirectionUri
            ) {
                authState, error in
                self.indicatorView.startAnimating()
                if let authState = authState {
                    self.setAuthState(authState)
                    let storyboard = UIStoryboard(name: "Main", bundle: nil)
                    let mainVC = storyboard.instantiateViewController(withIdentifier: "MainViewController") as! MainViewController
                    UIApplication.shared.windows.first?.rootViewController? = mainVC
                    UIApplication.shared.windows.first?.makeKeyAndVisible()
                    
                    print("Successful authorization.")
                    
                    self.showState()
                    
                    
                    if let completion = completion {
                        completion()
                    }
                } else {
                    print("Authorization error: \(error?.localizedDescription ?? "")")
                    
                    self.setAuthState(nil)
                }
            }
        }
        
        if let issuerUrl = issuerUrl {
            // Discovering OP configuration
            discoverOIDServiceConfiguration(issuerUrl) {
                configuration, error in
                guard let configuration = configuration else {
                    print("Error retrieving discovery document for \(issuerUrl): \(error?.localizedDescription ?? "")")
                    self.setAuthState(nil)
                    return
                }
                authorize(configuration: configuration)
            }
        } else if let configuration = configuration {
            // Accepting passed-in OP configuration
            authorize(configuration: configuration)
        }
    }
}

// MARK: OIDAuthState methods
extension ViewController {
    /**
     Saves authorization state in a storage.
     
     As an example, the user's defaults database serves as the persistent storage.
     */
    func saveState() {
        var data: Data? = nil
        if let authState = self.authState {
            if #available(iOS 12.0, *) {
                data = try! NSKeyedArchiver.archivedData(withRootObject: authState, requiringSecureCoding: false)
            } else {
                data = NSKeyedArchiver.archivedData(withRootObject: authState)
            }
        }
        
        UserDefaults.standard.set(data, forKey: FSConstants.AppAuthConfiguration.authStateKey)
        UserDefaults.standard.synchronize()
        
        print("Authorization state has been saved.")
    }
    
    /**
     Reacts on authorization state changes events.
     */
    func stateChanged() {
        self.saveState()
        /* if authState != nil {
         getUserInfo()
         } */
    }
    
    /**
     Assigns the passed in authorization state to the class property.
     Assigns this controller to the state delegate property.
     Reacts with UI changes.
     */
    func setAuthState(_ authState: OIDAuthState?) {
        if (self.authState != authState) {
            self.authState = authState
            
            self.authState?.stateChangeDelegate = self
            
            self.stateChanged()
        }
        
        //        showUi()
    }
    
    /**
     Loads authorization state from a storage.
     As an example, the user's defaults database serves as the persistent storage.
     */
    func loadState() {
        guard let data = UserDefaults.standard.object(forKey: FSConstants.AppAuthConfiguration.authStateKey) as? Data else {
            return
        }
        var authState: OIDAuthState? = nil
        
        if #available(iOS 12.0, *) {
            authState = try! NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data) as? OIDAuthState
        } else {
            authState = NSKeyedUnarchiver.unarchiveObject(with: data) as? OIDAuthState
        }
        
        if let authState = authState {
            print("Authorization state has been loaded.")
            
            self.setAuthState(authState)
        }
    }
    
    /**
     Displays selected information from the current authorization data.
     */
    func showState() {
        print("Current authorization state: ")
        print("Access token: \(authState?.lastTokenResponse?.accessToken ?? "none")")
        print("ID token: \(authState?.lastTokenResponse?.idToken ?? "none")")
        let idTokenClaims = getIdTokenClaims(idToken: authState?.lastTokenResponse?.idToken ?? "") ?? Data()
        print("ID token claims: \(String(describing: String(bytes: idTokenClaims, encoding: .utf8)))")
        print("Expiration date: \(String(describing: authState?.lastTokenResponse?.accessTokenExpirationDate))")
    }
}

// MARK: OIDAuthState delegates

extension ViewController: OIDAuthStateChangeDelegate {
    /**
     Responds to authorization state changes in the AppAuth library.
     */
    func didChange(_ state: OIDAuthState) {
        print("Authorization state change event.")
        
        self.stateChanged()
    }
}

extension ViewController: OIDAuthStateErrorDelegate {
    /**
     Reports authorization errors in the AppAuth library.
     */
    func authState(_ state: OIDAuthState, didEncounterAuthorizationError error: Error) {
        print("Received authorization error: \(error)")
    }
}

// MARK: URL request helpers
extension ViewController {
    /**
     Sends a URL request.
     
     Sends a predefined request and handles common errors.
     
     - Parameter urlRequest: URLRequest optionally crafted with additional information, which may include access token.
     - Parameter completion: Escaping completion handler allowing the caller to process the response.
     */
    func sendUrlRequest(urlRequest: URLRequest, completion: @escaping (Data?, HTTPURLResponse, URLRequest) -> Void) {
        let task = URLSession.shared.dataTask(with: urlRequest) {
            data, response, error in
            
            DispatchQueue.main.async {
                guard error == nil else {
                    // Handling transport error
                    print("HTTP request failed \(error?.localizedDescription ?? "")")
                    
                    return
                }
                
                guard let response = response as? HTTPURLResponse else {
                    // Expecting HTTP response
                    print("Non-HTTP response")
                    
                    return
                }
                
                completion(data, response, urlRequest)
            }
        }
        
        task.resume()
    }
    
    /**
     Makes a request to a protected source that accepts tokens from the OIDC Provider.
     
     - Parameter urlRequest: URLRequest with pre-defined URL, method, etc.
     - Parameter completion: Escaping completion handler allowing the caller to process the response.
     */
    func makeUrlRequestToProtectedResource(urlRequest: URLRequest, completion: @escaping (Data?, HTTPURLResponse, URLRequest) -> Void) {
        let currentAccessToken: String? = self.authState?.lastTokenResponse?.accessToken
        
        // Validating and refreshing tokens
        self.authState?.performAction() {
            accessToken, idToken, error in
            
            if error != nil {
                print("Error fetching fresh tokens: \(error?.localizedDescription ?? "")")
                
                // Replaying request to a protected resource after (re)authorization.
                self.authorizeRp(issuerUrl: FSConstants.AppAuthConfiguration.issuerUrl, configuration: nil) {
                    self.makeUrlRequestToProtectedResource(urlRequest: urlRequest, completion: completion)
                }
                
                return
            }
            
            guard let accessToken = accessToken else {
                print("Error getting accessToken")
                
                return
            }
            
            if currentAccessToken != accessToken {
                print("Access token was refreshed automatically (\(currentAccessToken ?? "none") to \(accessToken))")
            } else {
                print("Access token was fresh and not updated \(accessToken)")
            }
            
            var urlRequest = urlRequest
            
            // Including the access token in the request
            var requestHeaders = urlRequest.allHTTPHeaderFields ?? [:]
            requestHeaders["Authorization"] = "Bearer \(accessToken)"
            urlRequest.allHTTPHeaderFields = requestHeaders
            
//            self.sendUrlRequest(urlRequest: urlRequest) {
//                data, response, request in
//
//                guard let data = data, data.count > 0 else {
//                    print("HTTP response data is empty.")
//
//                    return
//                }
//
//                if response.statusCode != 200 {
//                    // Server replied with an error
//                    let responseText: String? = String(data: data, encoding: String.Encoding.utf8)
//
//                    if response.statusCode == 401 {
//                        // "401 Unauthorized" generally indicates there is an issue with the authorization grant; hence, putting OIDAuthState into an error state.
//
//                        // Checking if the response is a valid JSON.
//                        var json: [AnyHashable: Any]?
//
//                        do {
//                            json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
//                        } catch {
//                            print("JSON Serialization Error.")
//                        }
//
//                        let oauthError = OIDErrorUtilities.resourceServerAuthorizationError(
//                            withCode: 0,
//                            errorResponse: json,
//                            underlyingError: nil
//                        )
//
//                        self.authState?.update(withAuthorizationError: oauthError)
//
//                        print("Authorization Error (\(oauthError)). Response: \(responseText ?? "")")
//                    } else {
//                        print("HTTP: \(response.statusCode), Response: \(responseText ?? "")")
//                    }
//                }
//
//                completion(data, response, urlRequest)
//            }
        }
    }
}

// MARK: ID Token claims
extension ViewController {
    func getIdTokenClaims(idToken: String?) -> Data? {
        // Decoding ID token claims.
        
        var idTokenClaims: Data?
        
        if let jwtParts = idToken?.split(separator: "."), jwtParts.count > 1 {
            let claimsPart = String(jwtParts[1])
            
            let claimsPartPadded = padBase64Encoded(claimsPart)
            
            idTokenClaims = Data(base64Encoded: claimsPartPadded)
        }
        
        return idTokenClaims
    }
    
    /**
     Completes base64Encoded string to multiple of 4 to allow for decoding with NSData.
     */
    func padBase64Encoded(_ base64Encoded: String) -> String {
        let remainder = base64Encoded.count % 4
        
        if remainder > 0 {
            return base64Encoded.padding(toLength: base64Encoded.count + 4 - remainder, withPad: "=", startingAt: 0)
        }
        
        return base64Encoded
    }
}

// MARK: Delegate for the web view navigation events.
extension ViewController: WKNavigationDelegate {
    // Could be used to (automatically) load specific for the protection space cookies.
//    func webView(_ webView: WKWebView, didReceive challenge: URLAuthenticationChallenge, completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
//        indicatorView.startAnimating()
//
//        print(#function, challenge.protectionSpace.host, challenge.protectionSpace.authenticationMethod)
//
//        completionHandler(.performDefaultHandling, nil)
//    }
//
//    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
//        print(#function)
//        indicatorView.stopAnimating()
//
//    }
//
//    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
//        print(#function)
//    }
//
//    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
//        indicatorView.stopAnimating()
//        print(#function)
//    }
//
//    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!) {
//        print(#function)
//    }
//
//    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
//        print(#function, error.localizedDescription)
//    }
//
//    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
//        print(#function, error.localizedDescription)
//    }
    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        indicatorView.startAnimating()
        print(#function, navigationAction.request.url?.absoluteString ?? "")
        
        /**
         Handling the redirect from the authorization endpoint.
         
         Alternatively, for a custom URI scheme, one could use WKURLSchemeHandler; for example:
         let configuration = WKWebViewConfiguration()
         configuration.setURLSchemeHandler(your-class-adopting-the-WKURLSchemeHandler-protocol, forURLScheme: redirectionUriScheme)
         webView = WKWebView(frame: webViewFrame, configuration: configuration)
         */
        if navigationAction.request.url?.absoluteString.starts(with: FSConstants.AppAuthConfiguration.redirectionUri) ?? false {
            print("Redirection URI: ", navigationAction.request.url?.absoluteString ?? "")
            
            /**
             Redirection URI query parameters.
             */
            var parameters: [String : String] = [:]
            
            if let urlComponents = URLComponents(url: navigationAction.request.url!, resolvingAgainstBaseURL: false) {
                let queryItems: [URLQueryItem]? = urlComponents.queryItems
                if let queryItems = queryItems {
                    parameters = queryItems.reduce(into: parameters) {result, queryItem in
                        result[queryItem.name] = queryItem.value
                    }
                }
            }
            
            // Checking if the web view is associated with an OIDAuthorizationRequest.
            if let oidAuthorizationRequest = oidAuthorizationRequest {
                // Creating an OIDAuthorizationResponse to initiate token exchange request with.
                let oidAuthorizationResponse = OIDAuthorizationResponse(request: oidAuthorizationRequest, parameters: parameters as [String : NSCopying & NSObjectProtocol])
                
                // Verifying that the state in the response matches the state in the request.
                if oidAuthorizationRequest.state == oidAuthorizationResponse.state, let _ = oidAuthorizationResponse.authorizationCode {
                    // Saving the response in the authentication state object.
                    let authState = OIDAuthState(authorizationResponse: oidAuthorizationResponse)
                    
                    // Saving the authorization state.
                    setAuthState(authState)
                    
                    // Performing the token exchange and providing the callback on completion.
                    makeTokenRequest() {
                        authState, error in
                        
                        self.authorizationCompletion?(authState, error)
                    }
                } else {
                    setAuthState(nil)
                }
                
                decisionHandler(.cancel)
                view.viewWithTag(webViewTag)?.removeFromSuperview()
                self.indicatorView.stopAnimating()
                webViewController = nil
                
                return
            }
        }
        
        // Allowing navigation to and saving cookies from the issuer site.
        if navigationAction.request.url?.host == (URL(string: FSConstants.AppAuthConfiguration.issuerUrl))?.host {
            decisionHandler(.allow)
            // Capturing (authentication) cookies when they are present—after signing in at the authentication endpoint.
            WKWebsiteDataStore.default().httpCookieStore.getAllCookies() {
                cookies in

                let cookies = cookies.filter {
                    FSConstants.AppAuthConfiguration.appGroupCookies.contains($0.name)
                }

                guard cookies.count > 0 else {
                    return
                }

                self.webViewController.saveCookies(cookies)
            }

            // Dummy script imitating page content.
            var scriptSource = ""
            if let scriptPath = Bundle.main.path(forResource: "WebViewScriptSource", ofType: "js") {
                scriptSource = try! String(contentsOfFile: scriptPath)
            }
            let script = WKUserScript(source: scriptSource, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
            webView.configuration.userContentController.addUserScript(script)

            return
        }
        
        print("Cancelling navigation to: ", navigationAction.request.url?.absoluteString ?? "")
        
        decisionHandler(.cancel)
    }
    
    // Checking the web view responses and reporting errors.
    func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        print(#function)
        
        guard let statusCode = (navigationResponse.response as? HTTPURLResponse)?.statusCode else {
            print("Error: non-HTTP response")
            decisionHandler(.cancel)
            indicatorView.stopAnimating()
            
            return
        }
        guard statusCode < 400 else {
            print("Error: HTTP status code ", statusCode)
            decisionHandler(.cancel)
            
            return
        }
        
        // Allowing navigation if no errors are detected.
        decisionHandler(.allow)
    }
}

// MARK: Conforming to WKScriptMessageHandler protocol
extension ViewController: WKScriptMessageHandler {
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        print(#function)
        
        if message.name == "callback", let messageBody = message.body as? String, let messageBodyData = messageBody.data(using: .utf8) {
            let decoder = JSONDecoder()
            var messageBodyJson: AuthenticationResponse?
            
            do {
                messageBodyJson = try decoder.decode(AuthenticationResponse.self, from: messageBodyData)
                
                messageBodyJson?.callbacks.forEach {
                    callback in
                    
                    if callback.type == "code" {
                        /**
                         Example action against the web content.
                         */
                        let scriptSource = "(function () {document.body.style.backgroundColor = 'lightgreen'}())"
                        
                        // Example action performed in the native app.
                        
                        let webView = self.view.viewWithTag(webViewTag) as? WKWebView
                        
                        let alert = UIAlertController(title: "Native Prompt", message: "Enter the code. \nThe correct one is: 0000", preferredStyle: UIAlertController.Style.alert)
                        
                        alert.addTextField() {
                            textField in
                            
                            alert.addAction(
                                UIAlertAction(title: NSLocalizedString("Cancel", comment: "Cancel Action"), style: UIAlertAction.Style.cancel) {
                                    (_: UIAlertAction) in
                                    
                                    webView?.removeFromSuperview()
                                }
                            )
                            
                            alert.addAction(
                                UIAlertAction(title: NSLocalizedString("Submit", comment: "Submit Action"), style: UIAlertAction.Style.default) {
                                    (_: UIAlertAction) in
                                    
                                    let newValue = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines)
                                    
                                    if (newValue != "0000") {
                                        webView?.removeFromSuperview()
                                    } else {
                                        // Performing the action against the web content.
                                        webView?.evaluateJavaScript(scriptSource, completionHandler: nil)
                                    }
                                }
                            )
                        }
                        
                        present(alert, animated: false)
                    }
                }
            } catch {
                print("Error decoding callback message: ", error.localizedDescription)
            }
        }
    }
}
